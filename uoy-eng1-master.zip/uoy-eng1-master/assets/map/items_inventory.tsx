<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="items_inventory" tilewidth="16" tileheight="16" tilecount="408" columns="51">
 <image source="../../Downloads/town full/items_inventory.png" width="816" height="128"/>
</tileset>

<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="bird_common_black_animations" tilewidth="16" tileheight="16" tilecount="32" columns="4">
 <image source="animals/bird_common_black_animations.png" width="64" height="128"/>
</tileset>

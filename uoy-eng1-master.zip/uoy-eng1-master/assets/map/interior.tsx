<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="interior" tilewidth="16" tileheight="16" tilecount="9035" columns="139">
 <image source="interior/interior.png" width="2224" height="1040"/>
</tileset>

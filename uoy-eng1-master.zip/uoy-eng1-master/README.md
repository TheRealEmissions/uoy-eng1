# ENG1 Project

## Website
<https://therealemissions.github.io/uoy-eng1/>

## Contributors
- [Liam](https://github.com/TheRealEmissions)
- [Lucy](https://github.com/lc2353)
- [Tim](https://github.com/tgorst)
- [Sammy](https://github.com/sammyhori)
- [Zac](https://github.com/Zr695)
- [Kai]()
- [Lia]()

## Let Ron Cooke
Let Ron Cooke is a single-player student simulator, where the player controls Ron, and takes him through a week at University. Will he survive? Will he pass his exams? Will he get alcohol poisoning? Who knows!

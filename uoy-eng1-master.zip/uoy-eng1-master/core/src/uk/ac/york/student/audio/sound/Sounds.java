package uk.ac.york.student.audio.sound;

/**
 * Enum representing the different types of sounds in the game.
 */
public enum Sounds {
    BUTTON_CLICK
}
package uk.ac.york.student.assets.skins;

/**
 * This enum represents the different types of skins that can be used in the game.
 */
public enum Skins {
    CRAFTACULAR
}
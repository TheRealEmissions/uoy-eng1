package uk.ac.york.student.controllers;

@Deprecated(forRemoval = true)
public class KeyboardController {
}
